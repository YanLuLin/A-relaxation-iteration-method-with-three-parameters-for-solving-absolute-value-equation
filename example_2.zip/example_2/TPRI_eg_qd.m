function [omega,gamma,tau,IT,CPU,RES]=TPRI_eg_qd(m,mu,maxit,omega,gamma,tau)
eta=1.0e-6;
[A,b,x_star] = eg_2(m,mu);
[IT,CPU,RES,ERR,xk,omega,gamma,tau]=TPRI(A,b,x_star,omega,gamma,tau,eta,maxit); 
