function [omega,gamma,IT,CPU,RES]=GAOR_eg_qd(u,m,mu,maxit,omega,gamma)
tol=1.0e-6;
[A,b,x_star] = eg_2(m,mu);
[IT,CPU,RES]=GAOR(A,b,x_star,u,omega,gamma,tol,maxit); 
