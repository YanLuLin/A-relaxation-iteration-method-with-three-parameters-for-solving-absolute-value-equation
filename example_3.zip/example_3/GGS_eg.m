function [IT,CPU,RES]=GGS_eg(m,mu)
eta=1.0e-6;
maxit=300;
[A,b,x_star] = eg_3(m,mu);
[IT,CPU,RES,ERR,xk]=GGS(A,b,x_star,eta,maxit);